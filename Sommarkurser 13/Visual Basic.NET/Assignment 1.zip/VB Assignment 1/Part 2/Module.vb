﻿Option Explicit On
Option Strict On

'Module.vb, Car.vb
'Created by: Tim Fielding 10/06/2013
'Revised:

Module Module1

    Sub Main()
        Console.Title = "The gas consuming game!" 'Titletext <3
        Console.WriteLine("The goal of this program is for you to input different car-related values, then") 'Introduction text
        Console.WriteLine("set a distance you want to go and see if you make it on the amount of gas you have!")
        Dim Car As Car = New Car 'Object creation
        Car.Start() 'Object usage
        Console.WriteLine("Press any key to exit!") 'Good-bye text
        Console.ReadLine() 'To avoid the program instantly shutting down without requiring input
    End Sub

End Module
