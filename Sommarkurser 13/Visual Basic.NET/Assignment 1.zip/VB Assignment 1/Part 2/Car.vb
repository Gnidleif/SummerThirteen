﻿Option Explicit On
Option Strict On

Public Class Car
    Private mName As String 'Name variable, cars do have names
    Private mModel As String 'Name of the model of the car
    Private mGasAmount As Double 'Amount of gas from the start
    Private mGasPerMile As Double 'Amount of gas the car consumes per mile driven
    Private mMilesToGo As Integer 'Amount of miles you want to go

    Public Sub Start() 'Same here as in part1 pretty much
        ReadInput()
        PrintResult()
    End Sub

    Private Sub ReadInput() 'See Part1
        ReadName()
        ReadModel()
        ReadGasAmount()
        ReadGasPerMile()
        ReadMilesToGo()
    End Sub

    Private Sub PrintResult() 'Prints different results depending on if the CalculateGas method returns true or false
        If (CalculateGas()) Then 'If it's true, you win :D
            Print("You made it with " + CStr(mGasAmount) + " gallon(s) left!")
        Else 'If it's false, you don't win, but you get the amount of extra gas that you'd need back so you might learn something 
            Print("Sorry, you didn't make it, you needed " + (CStr(-mGasAmount)) + " more gallon(s) of gas to make it.")
        End If
    End Sub

    Private Sub ReadName() 'Straight forward read-methods below, with the only difference being them using my own defined methods for read/write
        Print("Name: ")
        mName = Read()
    End Sub

    Private Sub ReadModel()
        Print("Model: ")
        mModel = Read()
    End Sub

    Private Sub ReadGasAmount()
        Print("Amount of gas (gallons): ")
        mGasAmount = CDbl(Read())
    End Sub

    Private Sub ReadGasPerMile()
        Print("Gas per mile (gallons): ")
        mGasPerMile = CDbl(Read())
    End Sub

    Private Sub ReadMilesToGo()
        Print("Miles to go: ")
        mMilesToGo = CInt(Read())
    End Sub

    Private Function CalculateGas() As Boolean 'Calculates the amount of gas left after the trip, if it's 0 or less than 0 you didn't make it
        mGasAmount = mGasAmount - (mMilesToGo * mGasPerMile)
        Return mGasAmount > 0
    End Function

    Private Sub Print(ByVal message As String) 'Method encapsulating the Console.Writeline() function so I won't have to keep writing all that extra-code every time
        Console.WriteLine(message)
    End Sub

    Private Function Read() As String 'Same here, but with the ReadLine function
        Return Console.ReadLine().ToString()
    End Function

End Class
