﻿Option Explicit On
Option Strict On

Public Class GasPump
    Private mName As String 'Changed the names of the variables slightly
    Private mQuantity As Double 'If we were only supposed to input the amount of liters in whole numbers, why isn't this supposed to be an integer?
    Private mIsPremium As Boolean 'The boolean variable
    Private mTotal As Double 'Total price

    Private Const mRegular As Double = 7.48 'Made up numbers here
    Private Const mPremium As Double = 7.97 'Same here

    Public Sub Start() 'The "main"-method of this class
        ReadInput()
        CalcTotalToPay()
        PrintReceipt()
    End Sub

    Private Sub ReadInput() 'Gather all the methods handling the input from the user
        ReadName()
        ReadQuantity()
        ReadQuality()
    End Sub

    Private Sub CalcTotalToPay() 'Uses the boolean to decide which of the two gas prices that are supposed to be used
        If (mIsPremium) Then
            mTotal = mQuantity * mPremium
        Else
            mTotal = mQuantity * mRegular
        End If
    End Sub

    Private Sub PrintReceipt()
        Dim qualityPrint As String 'Variable used to store the chosen quality's name as a string
        Dim pricePrint As String 'Same here, but used to convert the different prices

        If (mIsPremium) Then 'Nothing weird here
            qualityPrint = "Premium"
            pricePrint = CStr(mPremium)
        Else
            qualityPrint = "Regular"
            pricePrint = CStr(mRegular)
        End If

        Console.WriteLine() 'The awesome "receipt"
        Console.WriteLine()
        Console.WriteLine("WELCOME TO THE AWESOME DUPER SUPER MEGA GAS STATION OF DOOM!")
        Console.WriteLine("Quality: " + qualityPrint)
        Console.WriteLine("Quantity: " + CStr(mQuantity))
        Console.WriteLine("Price per unit: " + pricePrint)
        Console.WriteLine("Sum to pay: " + CStr(mTotal))
        Console.WriteLine() 'Empty ones used to add new lines
        Console.WriteLine()
        Console.WriteLine("Please come again " + mName + "!")

    End Sub

    Private Sub ReadName()
        Console.WriteLine("What's your name? ") 'Input goes straight to the mName variable, since it's a string anyway
        mName = Console.ReadLine.ToString()
    End Sub

    Private Sub ReadQuantity()
        Console.Write("How many liters? ")
        Dim response As String = Console.ReadLine.ToString() 'Reads into a string
        mQuantity = CDbl(response) 'Converts from string to double
    End Sub

    Private Sub ReadQuality()
        Console.Write("Premium Quality? (y/n) ") '"Copy-pasted" from the instruction .pdf
        Dim response As Char = Console.ReadLine().Chars(0)
        If ((response = "y") Or (response = "Y")) Then
            mIsPremium = True
        Else
            mIsPremium = False
        End If
    End Sub

End Class
