﻿Option Explicit On
Option Strict On

'GasStationProg.vb, GasPump.vb
'Created by: Tim Fielding 10/06/2013
'Revised:

Module GasStationProg

    Sub Main()
        Console.Title = "Gas pump of doom!" 'Changed the title, for the lulz
        Dim GasPump As GasPump = New GasPump 'Declare and create a new GasPump-object
        GasPump.Start() 'Call the Start-method of the object
        Console.WriteLine("Press any key to exit!") 'Nice little text before exiting
        Console.ReadLine()
    End Sub

End Module
