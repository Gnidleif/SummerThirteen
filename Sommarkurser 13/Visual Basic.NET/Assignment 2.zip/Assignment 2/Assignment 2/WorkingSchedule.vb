﻿Option Explicit On
Option Strict On

'WorkingSchedule.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Public Class WorkingSchedule
    Private Const mTotalPeriod As Integer = 52 'All of these are actually used

    Private Const mNightStart As Integer = 1 'All of these are actually useful
    Private Const mNightPeriod As Integer = 6

    Private Const mWeekendStart As Integer = 6
    Private Const mWeekendPeriod As Integer = 3

    Public Sub Start()
        Dim choice As Integer = 0
        Do
            ShowMenu()
            choice = Input.ReadIntegerConsole()

            If (choice = 0) Then
            ElseIf (choice = 1) Then
                ShowNightSchedule()
            ElseIf (choice = 2) Then
                ShowWeekendSchedule()
            Else 'Default print, just in case someone done goofed!
                Menu.Print("Wrong choice, try again!")
            End If

        Loop While (choice <> 0)

    End Sub

    Private Sub ShowMenu() 'Shows the menu
        Menu.Print("Welcome to the work schedule program!")
        Menu.Print("0 : Go back to where you came from!")
        Menu.Print("1 : Show the night schedule for this year")
        Menu.Print("2 : Show the weekend schedule for this year")
        Console.Write("Choice: ")
    End Sub

    Private Sub ShowNightSchedule() 'Using a for-loop on both of these, since I knew how long I was going to iterate (i < 52)
        Dim i As Integer
        For i = mNightStart To mTotalPeriod Step mNightPeriod '(start, end-condition, increment-per-iteration)
            Menu.Print("Week: " + i.ToString())
        Next
    End Sub

    Private Sub ShowWeekendSchedule() 'I couldn't get the formatting on the text to get all fancy, I guess it has something to with my screen, since I wrote the code exactly like in the instructions
        Dim i As Integer
        For i = mWeekendStart To mTotalPeriod Step mWeekendPeriod
            Menu.Print("Week: " + i.ToString())
        Next
    End Sub

End Class
