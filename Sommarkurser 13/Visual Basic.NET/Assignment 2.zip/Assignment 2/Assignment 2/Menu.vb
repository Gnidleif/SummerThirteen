﻿Option Explicit On
Option Strict On

'Menu.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Public Class Menu

    Public Sub Start()
        Dim choice As Integer = -1 'Initialized to -1, or we would never enter the while-loop

        While (choice <> 0) 'While-loop making sure choice is never 0
            WriteMenuText()
            Console.Write("Choice: ")
            choice = Input.ReadIntegerConsole()

            Select Case choice
                Case 0
                    Print("Good bye!")
                Case 1
                    Dim localObject As WholeNumbersForAdd = New WholeNumbersForAdd()
                    localObject.Start()
                Case 2
                    Dim localObject As FloatingPointNumbersWhileAdd = New FloatingPointNumbersWhileAdd()
                    localObject.Start()
                Case 3
                    Dim localObject As CurrencyConverter = New CurrencyConverter()
                    localObject.Start()
                Case 4
                    Dim localObject As WorkingSchedule = New WorkingSchedule()
                    localObject.Start()
                Case Else
                    Print("You did something wrong, try again!")
            End Select
            Print("")
        End While
    End Sub

    Private Sub WriteMenuText() 'Menu print
        Console.Title = "Selection and iternation algorithms!"
        Print("Algorithms, iterations and bears, oh my!")
        Print("0 : Exit program")
        Print("1 : Whole numbers with for")
        Print("2 : Floating point numbers with while")
        Print("3 : Currency converter")
        Print("4 : Work schedule")
    End Sub

    Private Sub PrintNotImplemented(ByVal choice As Integer) 'Not used anymore, but useful for future expansions
        Print("Your selection was " + choice.ToString() + ", and that is not implemented yet.")
    End Sub

    Public Shared Sub Print(ByVal output As String) 'I liked the shared method thing, so I did it here too!
        Console.WriteLine(output)
    End Sub

    Public Shared Function Read() As String 'I really hate all the extra code from having to write it all out everytime
        Return Console.ReadLine()
    End Function

End Class
