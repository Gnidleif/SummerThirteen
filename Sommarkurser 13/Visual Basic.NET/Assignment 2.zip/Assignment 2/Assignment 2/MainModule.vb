﻿Option Explicit On
Option Strict On

'MainModule.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Module MainModule 'Simple main module

    Sub Main()
        Dim Menu As Menu = New Menu
        Menu.Start()
        Console.Read()
    End Sub

End Module
