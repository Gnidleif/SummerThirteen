﻿Option Explicit On
Option Strict On

'WholeNumbersForAdd.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Public Class WholeNumbersForAdd
    Private mNumInputs As Integer = 0 'Member variables
    Private mSum As Integer = 0

    Public Sub Start() 'Start method
        WriteProgramInfo()
        ReadInput()
        SumNumbers()
        WriteResults()
    End Sub

    Private Sub WriteProgramInfo() 'Yepp
        Menu.Print("Summation of whole numbers using a for-statement!")
    End Sub

    Private Sub ReadInput() 'Used to get the mNumInputs in place
        Console.Write("Number of values to sum up? ")
        mNumInputs = Input.ReadIntegerConsole()
        Menu.Print("")
    End Sub

    Private Sub SumNumbers() 'For loopin' and stuff!
        Dim i As Integer
        Dim num As Integer
        For i = 0 To mNumInputs - 1 Step 1 'This looks weird, but is useful
            Console.Write("Input no." + (i + 1).ToString() + ": ")
            num = Input.ReadIntegerConsole()
            mSum += num 'Adds up in the end of each iteration
        Next
    End Sub

    Private Sub WriteResults() 'Obvious method is obvious
        Menu.Print("Total sum after iteration: " + mSum.ToString())
        Menu.Print("")
    End Sub
End Class
