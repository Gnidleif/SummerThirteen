﻿Option Explicit On
Option Strict On

'CurrencyConverter.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Public Class CurrencyConverter
    Private mCurrencyName As String = "" 'Members, initialized and neat
    Private mRate As Double = 0.0
    Private mSum As Double = 0.0

    Public Sub Start() 'The usual start method
        WriteProgramInfo()
        ReadInputAndSumNumbers()
        ShowResults()
    End Sub

    Private Sub WriteProgramInfo() 'Name says it all
        Menu.Print("Summation of foreign exchange, using do-while!")
        Menu.Print("Input 0 when you want to quit.")
        Menu.Print("")
    End Sub

    Private Sub ReadInputAndSumNumbers() 'Reads the user's input and sums it up, all done in a do-while loop
        Dim num As Double = 0.0
        Dim done As Boolean = False

        Do
            Console.Write("Enter number: ")
            num = Input.ReadDoubleConsole()
            If (Math.Round(num, 2) = 0.0) Then
                done = True 'If the if is true, then so is the boolean "controlling" the looping
            Else
                mSum += num 'Add up the input number to the total sum
            End If
        Loop While (done <> True)

        Menu.Print("")
    End Sub

    Private Sub ShowResults() 'Shows the results, takes some more input from the user and shows the final result
        Dim converted As Decimal
        Menu.Print("Summation: " + mSum.ToString())
        Console.Write("Currency name: ")
        mCurrencyName = Menu.Read()
        Console.Write("Exchange rate: ")
        mRate = Input.ReadDoubleConsole()
        converted = CDec(mSum * mRate) 'Not really sure if this is what I was meant to do, but I guess so
        Menu.Print(mSum.ToString() + " converted to " + mCurrencyName + " = " + converted.ToString())
    End Sub

End Class
