﻿Option Explicit On
Option Strict On

'Input.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Public Class Input

    Public Shared Function ReadIntegerConsole() As Integer '"Copy-pasted" from the instructions
        Dim input As Integer
        If (Integer.TryParse(Console.ReadLine(), input)) Then
            Return input
        Else
            Console.WriteLine("Wrong input, please try again!")
            Return ReadIntegerConsole()
        End If
    End Function

    Public Shared Function ReadDoubleConsole() As Double
        Dim input As Double
        If (Double.TryParse(Console.ReadLine(), input)) Then
            Return input
        Else
            Console.WriteLine("Wrong input, please try again!")
            Return ReadDoubleConsole()
        End If
    End Function

End Class
