﻿Option Explicit On
Option Strict On

'FloatingPointNumbersWhileAdd.vb
'Created by: Tim Fielding 08/07/2013
'Revised:

Public Class FloatingPointNumbersWhileAdd
    Private mSum As Double = 0.0 'Initialized

    Public Sub Start() 'Start Method containing all of the other methods
        WriteProgramInfo()
        ReadInputAndSumNumbers()
        ShowResults()
    End Sub

    Private Sub WriteProgramInfo()
        Menu.Print("Summation of floating numbers using while-loop!")
        Menu.Print("Input 0 when you want to quit")
        Menu.Print("")
    End Sub

    Private Sub ReadInputAndSumNumbers() 'Read it, add it, loop it, quit the loopin'!
        Dim num As Double = 0.0
        Dim done As Boolean = False

        While (done <> True)
            Console.Write("Enter number: ")
            num = Input.ReadDoubleConsole()
            If (Math.Round(num, 5) = 0.0) Then '5 decimals was enough for me, everything else is just silly
                done = True
            Else
                mSum += num
            End If
        End While
        Menu.Print("")
    End Sub

    Private Sub ShowResults() 'Straightforward method printing the results
        Menu.Print("Total sum of all numbers: " + mSum.ToString())
    End Sub
End Class
