﻿Option Explicit On
Option Strict On

'Form1.vb
'Created by: Tim Fielding 12/08/2013
'Revised:

Public Class Form1
    Private mBakeryManager As BakeryManager

    ''' <summary>
    ''' Never accidentally set the constructor to Private, the program goes haywire, haha!
    ''' </summary>
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        mBakeryManager = New BakeryManager()
        InitializeGUI()
    End Sub
    ''' <summary>
    ''' Initializes the GUI to the startup values.
    ''' </summary>
    Private Sub InitializeGUI()
        txtAmount.Text = "0"
        txtPrice.Text = "0.0"
        lblReceipt.Text = "Nothing bought yet!"
        lblOverhead.Text = String.Format("{0, -15} {1, -15} {2, -15} {3, -15}", "Type:", "Price/Per:", "Total price:", "Amount:")

        For Each obj As BakeryTypes In System.Enum.GetValues(GetType(BakeryTypes)) 'Using a For Each loop to iterate through the enum
            cmbTypes.Items.Add(obj) 'Sets the combotype objects to the currently iterated object
        Next
    End Sub
    ''' <summary>
    ''' When the btnOK is clicked, it calls ReadInput(), if it returns false a MessageBox pops up
    ''' </summary>
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        If ReadInput() = False Then
            MessageBox.Show("Please select a valid type.", "Type error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    ''' <summary>
    ''' Calls the necessary functions in order to check the users' input
    ''' </summary>
    ''' <returns>
    ''' False if either a type was not selected or the input wasn't correct, true otherwise
    ''' </returns>
    Private Function ReadInput() As Boolean
        Dim returner As Boolean = False
        If Me.CheckTypeIndex() Then
            Me.CreateItem()

            If mBakeryManager.Item IsNot Nothing Then 'Checks the property of the BakeryManager if it's not nothing
                lblReceipt.Text = mBakeryManager.Item.ToString() 'If it isn't nothing, the receipt is set to the ToString() of the object
                mBakeryManager.ResetItem() 'Resets the mItem to Nothing to avoid bugs
                returner = True
            Else
                MessageBox.Show("Please input all values correctly!", "Input error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
        Return returner
    End Function
    ''' <summary>
    ''' Makes sure the value selected in the combobox is in range of the combobox
    ''' </summary>
    ''' <returns>
    ''' False if the item selected isn't in the range (nothing selected), otherwise true
    ''' </returns>
    Private Function CheckTypeIndex() As Boolean
        Return cmbTypes.SelectedIndex >= 0 And cmbTypes.SelectedIndex < cmbTypes.Items.Count
    End Function
    ''' <summary>
    ''' Uses a select case to change the corresponding labels to the correct values depending on what is currently selected
    ''' in the combobox.
    ''' </summary>
    Private Sub cmbTypes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTypes.SelectedIndexChanged
        Select Case Me.GetBakeryType()
            Case BakeryTypes.Cake
                lblAmount.Text = "Pieces:"
                lblPrice.Text = "Price/piece:"
            Case BakeryTypes.Cookie
                lblAmount.Text = "Weight:"
                lblPrice.Text = "Price/kg:"
        End Select
    End Sub
    ''' <summary>
    ''' This is basically where the magic happens, uses another Select Case to call the correct
    ''' subroutine in the BakeryManager to create an object
    ''' </summary>
    Private Sub CreateItem()
        Dim name As String = cmbTypes.Items(cmbTypes.SelectedIndex).ToString() 'Variables in the baseclass can be set outside the select case
        Dim price As Double = 0D
        InputUtility.GetDouble(txtPrice.Text, price)

        Select Case Me.GetBakeryType()
            Case BakeryTypes.Cake
                Dim pieces As Integer = 0
                InputUtility.GetInt(txtAmount.Text, pieces)
                If InputUtility.ValidateDouble(price) And InputUtility.ValidateInt(pieces) Then
                    mBakeryManager.CreateCake(name, price, pieces)
                End If
            Case BakeryTypes.Cookie
                Dim weight As Double = 0D
                InputUtility.GetDouble(txtAmount.Text, weight)
                If InputUtility.ValidateDouble(price) And InputUtility.ValidateDouble(weight) Then
                    mBakeryManager.CreateCookie(name, price, weight)
                End If
        End Select
    End Sub
    ''' <summary>
    ''' Loops through the enum again to check which one of the BakeryTypes is currently selected
    ''' </summary>
    ''' <returns>
    ''' The correct type selected
    ''' </returns>
    Private Function GetBakeryType() As BakeryTypes
        Dim returner As BakeryTypes = BakeryTypes.Cake 'Initiated to Cake just to initiate it to something
        Dim checker As String = cmbTypes.Items(cmbTypes.SelectedIndex).ToString() 'Comparison string set to the string of the selected item

        For Each obj As BakeryTypes In System.Enum.GetValues(GetType(BakeryTypes))
            If obj.ToString() = checker Then 'If the currently iterated object's ToString() returns the same as the comparison string, the if goes through
                returner = obj 'Returner object set to the currently iterated object
            End If
        Next

        Return returner
    End Function

End Class
