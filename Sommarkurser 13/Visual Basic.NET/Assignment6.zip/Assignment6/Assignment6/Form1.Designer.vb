﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpOrder = New System.Windows.Forms.GroupBox()
        Me.cmbTypes = New System.Windows.Forms.ComboBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblAmount = New System.Windows.Forms.Label()
        Me.lblItem = New System.Windows.Forms.Label()
        Me.grpReceipt = New System.Windows.Forms.GroupBox()
        Me.lblReceipt = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.lblOverhead = New System.Windows.Forms.Label()
        Me.grpOrder.SuspendLayout()
        Me.grpReceipt.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpOrder
        '
        Me.grpOrder.Controls.Add(Me.cmbTypes)
        Me.grpOrder.Controls.Add(Me.txtPrice)
        Me.grpOrder.Controls.Add(Me.txtAmount)
        Me.grpOrder.Controls.Add(Me.lblPrice)
        Me.grpOrder.Controls.Add(Me.lblAmount)
        Me.grpOrder.Controls.Add(Me.lblItem)
        Me.grpOrder.Location = New System.Drawing.Point(12, 12)
        Me.grpOrder.Name = "grpOrder"
        Me.grpOrder.Size = New System.Drawing.Size(260, 100)
        Me.grpOrder.TabIndex = 0
        Me.grpOrder.TabStop = False
        Me.grpOrder.Text = "Order"
        '
        'cmbTypes
        '
        Me.cmbTypes.FormattingEnabled = True
        Me.cmbTypes.Location = New System.Drawing.Point(133, 16)
        Me.cmbTypes.Name = "cmbTypes"
        Me.cmbTypes.Size = New System.Drawing.Size(121, 21)
        Me.cmbTypes.TabIndex = 4
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(154, 66)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtPrice.TabIndex = 3
        Me.txtPrice.Text = "0.0"
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(154, 43)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(100, 20)
        Me.txtAmount.TabIndex = 2
        Me.txtAmount.Text = "0"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Location = New System.Drawing.Point(6, 73)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(34, 13)
        Me.lblPrice.TabIndex = 2
        Me.lblPrice.Text = "Price:"
        '
        'lblAmount
        '
        Me.lblAmount.AutoSize = True
        Me.lblAmount.Location = New System.Drawing.Point(6, 50)
        Me.lblAmount.Name = "lblAmount"
        Me.lblAmount.Size = New System.Drawing.Size(46, 13)
        Me.lblAmount.TabIndex = 1
        Me.lblAmount.Text = "Amount:"
        '
        'lblItem
        '
        Me.lblItem.AutoSize = True
        Me.lblItem.Location = New System.Drawing.Point(6, 25)
        Me.lblItem.Name = "lblItem"
        Me.lblItem.Size = New System.Drawing.Size(30, 13)
        Me.lblItem.TabIndex = 0
        Me.lblItem.Text = "Item:"
        '
        'grpReceipt
        '
        Me.grpReceipt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.grpReceipt.Controls.Add(Me.lblOverhead)
        Me.grpReceipt.Controls.Add(Me.lblReceipt)
        Me.grpReceipt.Location = New System.Drawing.Point(12, 149)
        Me.grpReceipt.Name = "grpReceipt"
        Me.grpReceipt.Size = New System.Drawing.Size(260, 100)
        Me.grpReceipt.TabIndex = 1
        Me.grpReceipt.TabStop = False
        Me.grpReceipt.Text = "Receipt"
        '
        'lblReceipt
        '
        Me.lblReceipt.AutoSize = True
        Me.lblReceipt.Location = New System.Drawing.Point(6, 51)
        Me.lblReceipt.Name = "lblReceipt"
        Me.lblReceipt.Size = New System.Drawing.Size(100, 13)
        Me.lblReceipt.TabIndex = 3
        Me.lblReceipt.Text = "Nothing bought yet!"
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(92, 118)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(102, 25)
        Me.btnOK.TabIndex = 0
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'lblOverhead
        '
        Me.lblOverhead.AutoSize = True
        Me.lblOverhead.Location = New System.Drawing.Point(6, 28)
        Me.lblOverhead.Name = "lblOverhead"
        Me.lblOverhead.Size = New System.Drawing.Size(39, 13)
        Me.lblOverhead.TabIndex = 5
        Me.lblOverhead.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.grpReceipt)
        Me.Controls.Add(Me.grpOrder)
        Me.Name = "Form1"
        Me.Text = "Bakeryshop!"
        Me.grpOrder.ResumeLayout(False)
        Me.grpOrder.PerformLayout()
        Me.grpReceipt.ResumeLayout(False)
        Me.grpReceipt.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpOrder As System.Windows.Forms.GroupBox
    Friend WithEvents cmbTypes As System.Windows.Forms.ComboBox
    Friend WithEvents txtPrice As System.Windows.Forms.TextBox
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents lblPrice As System.Windows.Forms.Label
    Friend WithEvents lblAmount As System.Windows.Forms.Label
    Friend WithEvents lblItem As System.Windows.Forms.Label
    Friend WithEvents grpReceipt As System.Windows.Forms.GroupBox
    Friend WithEvents lblReceipt As System.Windows.Forms.Label
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lblOverhead As System.Windows.Forms.Label

End Class
