﻿Option Strict On
Option Explicit On

'BakeryItem.vb
'Created by: Tim Fielding 12/08/2013
'Revised:


''' <summary>
''' MustInherit before this class's name basically means that you can't create an object of it,
''' only objects of it's subclasses may be created
''' </summary>
Public MustInherit Class BakeryItem
    Private mName As String = String.Empty
    Private mPrice As Double = 0D
    ''' <summary>
    ''' Constructor taking the variables that are shared between all the subclasses as parameters
    ''' </summary>
    Public Sub New(ByVal name As String, ByVal price As Double)
        mName = name
        mPrice = price
    End Sub
    ''' <summary>
    ''' A non-implemented, or abstract, function that is only implemented in the subclasses,
    ''' this is useful since all of the subclasses will need a way to calculate the total price
    ''' of themselves, but all of them will probably have different ways of calculating that.
    ''' Return type is a double since the mPrice is a double.
    ''' </summary>
    Public MustOverride Function CalcTotal() As Double
    ''' <summary>
    ''' Overridden version of the ToString()-function used to get a custom version of a ToString() 
    ''' from this class, in this case it's a formatted string
    ''' </summary>
    Public Overrides Function ToString() As String
        Return String.Format("{0, -15} {1, -15} {2, -15}", Me.Name, Me.Price, Me.CalcTotal().ToString())
    End Function
    ''' <summary>
    ''' Properties! Not much to say here really. Get/set functions.
    ''' </summary>
    Public Property Name() As String
        Get
            Return mName
        End Get
        Set(value As String)
            If InputUtility.ValidateString(value) Then
                mName = value
            End If
        End Set
    End Property

    Public Property Price() As Double
        Get
            Return mPrice
        End Get
        Set(value As Double)
            If InputUtility.ValidateDouble(value) Then
                mPrice = value
            End If
        End Set
    End Property

End Class
