﻿'BakeryTypes.vb
'Created by: Tim Fielding 12/08/2013
'Revised:

''' <summary>
''' Simple enum used to store different bakerytypes
''' </summary>
Public Enum BakeryTypes
    Cake
    Cookie
End Enum