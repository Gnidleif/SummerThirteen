﻿Option Explicit On
Option Strict On

'BakeryManager.vb
'Created by: Tim Fielding 12/08/2013
'Revised:

''' <summary>
''' A slightly weird class used to control and check which one of the subclass-types
''' needs to be created and calculated
''' </summary>
Public Class BakeryManager
    Private mItem As BakeryItem
    ''' <summary>
    ''' Constructor only calls ResetItem() which sets the mItem, which is an item of the
    ''' abstract type BakeryItem. Since the BakeryItem-class is abstract the constructor
    ''' can't be called directly from any object, but it's fine to use it to call the
    ''' constructor of various subclasses.
    ''' </summary>
    Public Sub New()
        ResetItem()
    End Sub
    ''' <summary>
    ''' Sets the mItem back to Nothing after a receipt has been printed to avoid silly bugs
    ''' </summary>
    Public Sub ResetItem()
        mItem = Nothing
    End Sub
    ''' <summary>
    ''' Creates a cake with the specified parameters, called when the necessary conditions are okay in Form1
    ''' </summary>
    Public Sub CreateCake(ByVal name As String, ByVal price As Double, ByVal pieces As Integer)
        mItem = New Cake(name, price, pieces)
    End Sub
    ''' <summary>
    ''' Same as the above, only with a cookie
    ''' </summary>
    Public Sub CreateCookie(ByVal name As String, ByVal price As Double, ByVal weight As Double)
        mItem = New Cookie(name, price, weight)
    End Sub
    ''' <summary>
    ''' A readonly property used to return the mItem, this is used by Form1 to determine the current
    ''' type of the mItem, and therefore letting it know what it's supposed to show the user.
    ''' </summary>
    Public ReadOnly Property Item() As BakeryItem
        Get
            Return mItem
        End Get
    End Property

End Class
