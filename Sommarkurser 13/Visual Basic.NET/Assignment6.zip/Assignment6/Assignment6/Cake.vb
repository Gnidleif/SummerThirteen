﻿Option Strict On
Option Explicit On

'Cake.vb
'Created by: Tim Fielding 12/08/2013
'Revised:

''' <summary>
''' Cake class derived from the BakeryItem baseclass
''' </summary>
Public Class Cake : Inherits BakeryItem
    Private mPieces As Integer = 0
    ''' <summary>
    ''' Constructor which first calls the constructor of the baseclass, then sets the 
    ''' value of the subclass's specific variable, mPieces
    ''' </summary>
    Public Sub New(ByVal name As String, ByVal price As Double, ByVal pieces As Integer)
        MyBase.New(name, price)
        mPieces = pieces
    End Sub
    ''' <summary>
    ''' The Cake-implementation of the abstract CalcTotal() function
    ''' </summary>
    ''' <returns>
    ''' The total price of the mPieces times the Price of the object
    ''' </returns>
    Public Overrides Function CalcTotal() As Double
        Return mPieces * MyBase.Price
    End Function
    ''' <summary>
    ''' Another overridden ToString() which adds together the formatted string from the baseclass with
    ''' the "local" formatted string from this class.
    ''' </summary>
    Public Overrides Function ToString() As String
        Return MyBase.ToString() + String.Format("{0, -5}", mPieces)
    End Function
    ''' <summary>
    ''' Property again, gets/sets the amount of pieces
    ''' </summary>
    Public Property Pieces() As Integer
        Get
            Return mPieces
        End Get
        Set(value As Integer)
            If InputUtility.ValidateInt(value) Then
                mPieces = value
            End If
        End Set
    End Property

End Class
