﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Address.cs
// Tim Fielding 11/08/2013

namespace Assignment_5
{
    /// <summary>
    /// Class used to store address-related data
    /// </summary>
    class Address
    {
        private string mStreet;
        private string mCity;
        private string mZip;
        private Countries mCountry;
        /// <summary>
        /// The default constructor, default city is Karlskrona
        /// </summary>
        public Address()
            : this(string.Empty, string.Empty, "Karlskrona") { }
        /// <summary>
        /// The constructor taking street, zipcode and city as parameters, default country is Sweden
        /// </summary>
        public Address(string street, string zip, string city)
            : this(street, zip, city, Countries.Sverige) { }
        /// <summary>
        /// The constructor taking all variables as parameters
        /// </summary>
        public Address(string street, string zip, string city, Countries country)
        {
            this.mStreet = street;
            this.mZip = zip;
            this.mCity = city;
            this.mCountry = country;
        }
        /// <summary>
        /// Returns a string of the country without the underscores used in the Countries-enum
        /// </summary>
        private string GetCountryString()
        {
            string strCountry = mCountry.ToString();
            strCountry = strCountry.Replace("_", " ");
            return strCountry;
        }
        /// <summary>
        /// A method overriding the original ToString()-method to be able to use the string.Format when typing .ToString() after an object of this type
        /// </summary>
        /// <returns>
        /// Returns a correctly formatted string of all the data in this object
        /// </returns>
        public override string ToString()
        {
            return string.Format("{0, -25} {1, -8} {2, -10} {3}", mStreet, mZip, mCity, this.GetCountryString());
        }
        /// <summary>
        /// Properties, very neat, not using the set-part of them though since that's not really needed
        /// </summary>
        public string Street
        {
            get { return this.mStreet; }
        }

        public string City
        {
            get { return this.mCity; }
        }

        public string Zip
        {
            get { return this.mZip; }
        }

        public Countries Country
        {
            get { return this.mCountry; }
        }
    }
}
