﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// ContactManager.cs
// Tim Fielding 11/08/2013

namespace Assignment_5
{
    /// <summary>
    /// Class handling the contacts in a List
    /// </summary>
    class ContactManager
    {
        private List<Contact> mContacts;
        /// <summary>
        /// Default constructor
        /// </summary>
        public ContactManager()
        {
            this.mContacts = new List<Contact>();
        }
        /// <summary>
        /// Adds a contact using firstname and surname and an address
        /// </summary>
        /// <returns>
        /// True if the strings can be validated correctly and the address isn't null
        /// </returns>
        public bool AddContact(string firstName, string surname, Address address)
        {
            bool returner = false;
            if(InputUtility.ValidateString(firstName) && InputUtility.ValidateString(surname) && address != null)
            {
                this.mContacts.Add(new Contact(firstName, surname, address));
                returner = true;
            }
            return returner;
        }
        /// <summary>
        /// Same as the above, only using a contact-variable instead
        /// </summary>
        /// <returns>
        /// True if the contact sent wasn't null
        /// </returns>
        public bool AddContact(Contact contact)
        {
            bool returner = false;
            if (contact != null)
            {
                this.mContacts.Add(contact);
                returner = true; ;
            }
            return returner;
        }
        /// <summary>
        /// Method used to change a contact at a given index to the new contact sent in
        /// </summary>
        /// <returns>
        /// False if the parameters sent doesn't cut it
        /// </returns>
        public bool ChangeContact(Contact contact, int index)
        {
            bool returner = false;
            if(contact != null || this.CheckIndex(index))
            {

                this.mContacts[index] = contact;
                returner = true;
            }
            return returner;
        }
        /// <summary>
        /// Removes a contact at a given index
        /// </summary>
        /// <returns>
        /// False if the index sent isn't valid
        /// </returns>
        public bool DeleteContact(int index)
        {
            bool returner = false;
            if (this.CheckIndex(index))
            {
                this.mContacts.RemoveAt(index);
                returner = true;
            }
            return returner;
        }
        /// <summary>
        /// Returns a contact at a given index
        /// </summary>
        /// <returns>
        /// A proper contact if the index was good, a contact variable set to null if it wasn't
        /// </returns>
        public Contact GetContact(int index)
        {
            Contact contact = null; // First i create an empty contact

            if (this.CheckIndex(index)) // If the index checks out, I move on
            {
                contact = mContacts[index]; // The local variable is then set to the contact at the given index
            }

            return contact;
        }
        /// <summary>
        /// Builds a string array made up of all the contacts in the list
        /// </summary>
        /// <returns>
        /// Returns the string array
        /// </returns>
        public string[] GetContactsInfo()
        {
            string[] infoStrings = new string[this.Count]; // Initializes the array to be the size of the list

            int i = 0;
            foreach (Contact obj in mContacts) // Foreach loops <3
            {
                infoStrings[i++] = obj.ToString(); // Sets the local array to the object currently being iterated casted to a string
            }

            return infoStrings;
        }
        /// <summary>
        /// Returns the current size of the list
        /// </summary>
        public int Count
        {
            get { return this.mContacts.Count; }
        }
        /// <summary>
        /// Checks if a tried index is valid (inside the range of the list)
        /// </summary>
        /// <param name="index">
        /// The index to be tried
        /// </param>
        /// <returns>
        /// True if it's inside the range of the list, false otherwise
        /// </returns>
        private bool CheckIndex(int index)
        {
            return (index >= 0 && index < this.Count);
        }
    }
}
