﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Contact.cs
// Tim Fielding 11/08/2013

namespace Assignment_5
{
    /// <summary>
    /// Class used to store information on each contact in the program
    /// </summary>
    class Contact
    {
        private string mFirstName = string.Empty;
        private string mSurname = string.Empty;
        private Address mAddress;
        /// <summary>
        /// Default constructor
        /// </summary>
        public Contact()
            : this(string.Empty, string.Empty, new Address()) { } // I like how this thing with calling the constructor "above" works!
        /// <summary>
        /// The non-default constructor
        /// </summary>
        public Contact(string firstName, string surname, Address address)
        {
            this.mFirstName = firstName;
            this.mSurname = surname;
            this.mAddress = address;
        }
        /// <summary>
        /// Another overridden ToString() method, but for the Contact-class instead of the address class
        /// </summary>
        public override string ToString()
        {
            return string.Format("{0, -20} {1}", this.FullName, this.mAddress.ToString());
        }
        /// <summary>
        /// Properties!
        /// </summary>
        public string FirstName
        {
            get { return this.mFirstName; }
            set { this.mFirstName = value; }
        }

        public string Surname
        {
            get { return this.mSurname; }
            set { this.mSurname = value; }
        }
        /// <summary>
        /// A property used to get a string with both the first- and surname of this contact
        /// </summary>
        public string FullName
        {
            get { return this.mFirstName + " " + this.mSurname; }
        }

        public Address AddressData
        {
            get { return this.mAddress; }
            set { this.mAddress = value; }
        }
    }
}
