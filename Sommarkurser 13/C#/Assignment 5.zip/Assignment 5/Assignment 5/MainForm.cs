﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// MainForm.cs
// Tim Fielding 11/08/2013

namespace Assignment_5
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// The class responsible for handling output/input to the user
        /// </summary>
        ContactManager mContactManager;
        public MainForm()
        {
            InitializeComponent();

            mContactManager = new ContactManager();
            InitializeGUI();
        }
        /// <summary>
        /// Initializes the GUI with default values
        /// </summary>
        private void InitializeGUI()
        {
            txtFirstName.Text = "Name...";
            txtSurname.Text = "Surname...";
            txtStreet.Text = "Street...";
            txtCity.Text = "City...";
            txtZip.Text = "Zip...";
            
            foreach (Countries obj in Enum.GetValues(typeof(Countries))) // Iterates over each of the objects in the enum to fill the combobox
            {
                cmbCountries.Items.Add(obj);
            }
        }
        /// <summary>
        /// Updates the GUI after a change is made
        /// </summary>
        private void UpdateGui()
        {
            lstRecords.Items.Clear();
            lstRecords.Items.AddRange(mContactManager.GetContactsInfo());
            lblNoRecord.Text = mContactManager.Count.ToString();
        }
        /// <summary>
        /// A method used to call the UpdateContactInfo() when any object in the listbox is clicked
        /// </summary>
        private void lstRecords_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.UpdateContactInfo();
        }
        /// <summary>
        /// Updates the text in the different textboxes to the values in the object currently selected in the listbox
        /// </summary>
        private void UpdateContactInfo()
        {
            Contact contact = mContactManager.GetContact(lstRecords.SelectedIndex);

            cmbCountries.SelectedIndex = (int)contact.AddressData.Country;
            txtFirstName.Text = contact.FirstName;
            txtSurname.Text = contact.Surname;
            txtStreet.Text = contact.AddressData.Street;
            txtCity.Text = contact.AddressData.City;
            txtZip.Text = contact.AddressData.Zip;
        }
        /// <summary>
        /// Method used to add contacts to the mContactManager
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string firstname = string.Empty;
            string surname = string.Empty;

            if (ReadNameInfo( // Checks the names written in the textboxes
                out firstname,
                out surname))
            {
                Address address = this.ReadAddressInfo();
                Contact contact = new Contact(firstname, surname, address);
                mContactManager.AddContact(contact);
                UpdateGui();
            }
        }
        /// <summary>
        /// Method used to change an existing contact in the mContactManager
        /// </summary>
        private void btnChange_Click(object sender, EventArgs e)
        {
            string firstname = string.Empty;
            string surname = string.Empty;

            if (ReadNameInfo( // This has to check both names AND if anything in the listbox is actually selected
                out firstname,
                out surname)
                &&
                CheckRecordIndex())
            {
                int index = lstRecords.SelectedIndex;
                Address address = this.ReadAddressInfo();
                Contact contact = new Contact(firstname, surname, address);
                mContactManager.ChangeContact(contact, index);
                UpdateGui();
            }
        }
        /// <summary>
        /// Method used to describe what happens when the delete-button is clicked
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (CheckRecordIndex()) // Something has to be selected for something to be deleted
            {
                int index = lstRecords.SelectedIndex;
                mContactManager.DeleteContact(index);
                UpdateGui();
            }
        }
        /// <summary>
        /// Method used to check if anything is selected in the country combobox
        /// </summary>
        /// <returns>
        /// False if the selected index is out of range of the list in the combobox, true otherwise
        /// </returns>
        private bool CheckCountryIndex()
        {
            return
                cmbCountries.SelectedIndex >= 0 &&
                cmbCountries.SelectedIndex < cmbCountries.Items.Count;
        }
        /// <summary>
        /// Method used to check if anything is selected in the listbox
        /// </summary>
        /// <returns>
        /// True if the selected index is within range of the items in the listbox
        /// </returns>
        private bool CheckRecordIndex()
        {
            return
                lstRecords.SelectedIndex >= 0 &&
                lstRecords.SelectedIndex < mContactManager.Count;
        }
        /// <summary>
        /// A method used to call both the ReadFirstName and ReadSurName methods
        /// </summary>
        /// <returns>
        /// True if both of the called methods check out
        /// </returns>
        private bool ReadNameInfo(
            out string firstname,
            out string surname)
        {
            firstname = string.Empty;
            surname = string.Empty;

            return
                ReadFirstName(out firstname) &&
                ReadSurname(out surname);
        }
        /// <summary>
        /// Method used to call the different methods needed to be checked when creating an address
        /// </summary>
        /// <returns>
        /// The new address, dependant on what was selected and typed into the different data fields of the mainform
        /// </returns>
        private Address ReadAddressInfo()
        {
            Address returner = new Address(); // Object to be returned first initialized as default before checking other things
            if (CheckAddressStrings())
            {
                // If either of the address data fields were filled in, the second constructor is called
                returner = new Address(txtStreet.Text, txtZip.Text, txtCity.Text);
            }

            if (CheckCountryIndex()) // If any country was selected, the third constructor is called
            {
                Countries country = Countries.Sverige;
                string checker = cmbCountries.Items[cmbCountries.SelectedIndex].ToString();

                // Foreach used to iterate over the countries and see which one was selected, 
                // the correct object is then sent in to the third constructor
                foreach (Countries obj in Enum.GetValues(typeof(Countries)))
                {
                    if (obj.ToString() == checker) // If the object currently being checked cast to a string is the same as the comparison string
                    {
                        country = obj; // The country-object is set to the currently iterated object
                        break; // Breaks the loop to avoid extra iterations after the object is found
                    }
                }
                // Calling third constructor with all the data
                returner = new Address(txtStreet.Text, txtZip.Text, txtCity.Text, country);
            }
            return returner;
        }
        /// <summary>
        /// A method both checking the validity of the Text in the textbox 
        /// and sets the object sent as a parameter to the value of the textbox if the textbox.text checks out
        /// </summary>
        /// <param name="data">
        /// The string sent as a reference parameter
        /// </param>
        /// <returns>
        /// True if the string was valid and the parameter set to the value of the textbox
        /// </returns>
        private bool ReadFirstName(out string data)
        {
            bool returner = false;
            data = string.Empty;
            if (InputUtility.ValidateString(txtFirstName.Text))
            {
                data = txtFirstName.Text;
                returner = true;
            }
            return returner;
        }
        /// <summary>
        /// A method both checking the validity of the Text in the textbox 
        /// and sets the object sent as a parameter to the value of the textbox if the textbox.text checks out
        /// </summary>
        /// <param name="data">
        /// The string sent as a reference parameter
        /// </param>
        /// <returns>
        /// True if the string was valid and the parameter set to the value of the textbox
        /// </returns>
        private bool ReadSurname(out string data)
        {
            bool returner = false;
            data = string.Empty;
            if (InputUtility.ValidateString(txtSurname.Text))
            {
                data = txtSurname.Text;
                returner = true;
            }
            return returner;
        }
        /// <summary>
        /// Method used to check the different address strings
        /// </summary>
        /// <returns>
        /// If either of the called methods return true, this method returns true
        /// </returns>
        private bool CheckAddressStrings()
        {
            return CheckStreet() || CheckCity() || CheckZip();
        }
        /// <summary>
        /// All of the below methods are used to check the validity different textbox strings
        /// </summary>
        /// <returns>
        /// True if the string checked is valid, false otherwise
        /// </returns>
        private bool CheckStreet()
        {
            return InputUtility.ValidateString(txtStreet.Text);
        }

        private bool CheckCity()
        {
            return InputUtility.ValidateString(txtCity.Text);
        }

        private bool CheckZip()
        {
            return InputUtility.ValidateString(txtZip.Text);
        }
    }
}
