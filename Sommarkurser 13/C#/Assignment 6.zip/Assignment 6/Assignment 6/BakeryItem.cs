﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// BakeryItem.cs
// Tim Fielding 11/08/2013

namespace Assignment_6
{
    /// <summary>
    /// This class is abstract since only objects of the various subclasses will ever be created
    /// </summary>
    abstract class BakeryItem
    {
        private string mName = string.Empty;
        private double mPrice = 0.0d;
        /// <summary>
        /// Constructor
        /// </summary>
        public BakeryItem(string name, double price)
        {
            this.mName = name;
            this.mPrice = price;
        }
        /// <summary>
        /// Abstract method, since different subclasses will have different ways to calculate the total price
        /// </summary>
        public abstract double CalcTotal();
        /// <summary>
        /// Overrides the normal ToString() method
        /// </summary>
        public override string ToString()
        {
            return "Item: " + mName + "\nTotal price: $" + CalcTotal().ToString();
        }
        /// <summary>
        /// Properties!
        /// </summary>
        public string Name
        {
            get { return this.mName; }
            set
            {
                if (InputUtility.ValidateString(value))
                {
                    this.mName = value;
                }
            }
        }

        public double Price
        {
            get { return this.mPrice; }
            set
            {
                if(InputUtility.ValidateDouble(value))
                {
                    this.mPrice = value;
                }
            }
        }
    }
}
