﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// BakeryManager.cs
// Tim Fielding 11/08/2013

namespace Assignment_6
{
    /// <summary>
    /// A class used to store a BakeryItem object which is used for various stuff
    /// </summary>
    class BakeryManager
    {
        BakeryItem mItem;
        /// <summary>
        /// Constructor calling the ResetItem() method which sets the mItem to null
        /// </summary>
        public BakeryManager()
        {
            ResetItem();
        }
        /// <summary>
        /// Property!
        /// </summary>
        public BakeryItem Item
        {
            get { return this.mItem; }
        }
        /// <summary>
        /// Sets the mItem to null, used from the MainForm after the receipt is printed
        /// </summary>
        public void ResetItem()
        {
            mItem = null;
        }
        /// <summary>
        /// Creates a cake with the parameter variables as values
        /// </summary>
        public void CreateCake(string name, double price, int pieces)
        {
            mItem = new Cake(name, price, pieces);
        }
        /// <summary>
        /// Creates a cookie with the parameter variables as values
        /// </summary>
        public void CreateCookie(string name, double price, double weight)
        {
            mItem = new Cookie(name, price, weight);
        }
    }
}
