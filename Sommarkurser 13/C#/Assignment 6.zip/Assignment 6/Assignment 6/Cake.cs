﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Cake.cs
// Tim Fielding 11/08/2013

namespace Assignment_6
{
    /// <summary>
    /// Cake, a subclass to the BakeryItem abstract class
    /// </summary>
    class Cake : BakeryItem
    {
        private int mPieces = 0;
        /// <summary>
        /// Constructor, first two parameters are sent to the baseclass
        /// </summary>
        public Cake(string name, double price, int pieces)
            : base(name, price)
        {
            this.mPieces = pieces;
        }
        /// <summary>
        /// Overrides the abstract method in BakeryItem to calculated the price 
        /// </summary>
        /// <returns>
        /// Returns the total price of the object
        /// </returns>
        public override double CalcTotal()
        {
            return mPieces * base.Price;
        }
        /// <summary>
        /// Overrides the normal ToString() method and calls the baseclass ToString()
        /// </summary>
        /// <returns>
        /// Returns the total string of the item (including values in the baseclass)
        /// </returns>
        public override string ToString()
        {
            return base.ToString() + "\nPieces: " + mPieces.ToString();
        }
        /// <summary>
        /// Property!
        /// </summary>
        public int Pieces
        {
            get { return this.mPieces; }
            set
            {
                if (InputUtility.ValidateInteger(value))
                {
                    mPieces = value;
                }
            }
        }
    }
}
