﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// BakeryManager.cs
// Tim Fielding 11/08/2013

namespace Assignment_6
{
    public partial class MainForm : Form
    {
        BakeryManager mBakeryManager;
        /// <summary>
        /// Constructor, calls the InitializeGUI() method
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            mBakeryManager = new BakeryManager();
            InitializeGUI();
        }
        /// <summary>
        /// Initializes the values of the different textstuff on the MainForm
        /// </summary>
        private void InitializeGUI()
        {
            txtAmount.Text = "0";
            txtPrice.Text = "0.0";
            lblTotal.Text = "Nothing bought!";

            foreach (BakeryTypes obj in Enum.GetValues(typeof(BakeryTypes)))
            {
                cmbTypes.Items.Add(obj);
            }
        }
        /// <summary>
        /// When the ok-button is clicked, ReadInput is called
        /// </summary>
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!this.ReadInput())
            {
                MessageBox.Show(
                    "No bakery type was selected!",
                    "Type error!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// Uses a few different methods to decide what to put in the output window
        /// </summary>
        private bool ReadInput()
        {
            bool returner = false;
            if (CheckTypeIndex())
            {
                this.CreateItem();

                if (mBakeryManager.Item != null) // If item is okay, sets the label to the correct string
                {
                    lblTotal.Text = mBakeryManager.Item.ToString();
                    mBakeryManager.ResetItem();
                    returner = true;
                }
                else // Else it shows a messagebox
                {
                    MessageBox.Show(
                        "Please input all values correctly",
                        "Input error!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }

            }
            return returner;
        }
        /// <summary>
        /// Switches the labeltexts depending on what item in the combobox is currently selected
        /// </summary>
        private void cmbTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (GetBakeryType())
            {
                case BakeryTypes.Cake:
                    lblAmount.Text = "Pieces:";
                    lblPrice.Text = "Price/piece:";
                    break;

                case BakeryTypes.Cookie:
                    lblAmount.Text = "Weight:";
                    lblPrice.Text = "Price/kg:";
                    break;
            }
        }
        /// <summary>
        /// Checks if the selected index in the combobox is within range of the items in the combobox
        /// </summary>
        /// <returns>
        /// True if it's in the range, false if not
        /// </returns>
        private bool CheckTypeIndex()
        {
            return
                cmbTypes.SelectedIndex >= 0 &&
                cmbTypes.SelectedIndex < cmbTypes.Items.Count;
        }
        /// <summary>
        /// Used to decide which item the BakeryManager should create
        /// </summary>
        private void CreateItem()
        {
            string name = cmbTypes.Items[cmbTypes.SelectedIndex].ToString();
            double price = 0.0d;
            InputUtility.GetDouble(txtPrice.Text, out price);

            switch (GetBakeryType()) // Switch used to decide which of the enum-values are currently selected
            {
                case BakeryTypes.Cake:
                    int pieces = 0;
                    InputUtility.GetInt(txtAmount.Text, out pieces);
                    if (InputUtility.ValidateDouble(price) && InputUtility.ValidateDouble(pieces))
                    {
                        mBakeryManager.CreateCake(name, price, pieces);
                    }
                    break;

                case BakeryTypes.Cookie:
                    double weight = 0.0d;
                    InputUtility.GetDouble(txtAmount.Text, out weight);
                    if (InputUtility.ValidateDouble(price) && InputUtility.ValidateDouble(weight))
                    {
                        mBakeryManager.CreateCookie(name, price, weight);
                    }
                    break;
            }
        }
        /// <summary>
        /// Decides which BakeryType is currently selected in the combobox
        /// </summary>
        /// <returns>
        /// Returns the correct BakeryType;
        /// </returns>
        private BakeryTypes GetBakeryType()
        {
            BakeryTypes returner = BakeryTypes.Cake;
            string checker = cmbTypes.Items[cmbTypes.SelectedIndex].ToString();

            foreach (BakeryTypes obj in Enum.GetValues(typeof(BakeryTypes)))
            {
                if (obj.ToString() == checker)
                {
                    returner = obj;
                    break;
                }
            }
            return returner;
        }

        /// <summary>
        /// Accidentally double-clicked an item again :C
        /// </summary>
        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
