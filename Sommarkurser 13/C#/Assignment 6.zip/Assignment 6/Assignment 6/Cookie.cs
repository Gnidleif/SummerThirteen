﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Cookie.cs
// Tim Fielding 11/08/2013

namespace Assignment_6
{
    /// <summary>
    /// Cookie, a subclass to the BakeryItem abstract class
    /// </summary>
    class Cookie : BakeryItem
    {
        private double mWeight = 0.0d;
        /// <summary>
        /// Constructor, first two parameters are sent to the baseclass
        /// </summary>
        public Cookie(string name, double price, double weight)
            : base(name, price)
        {
            this.mWeight = weight;
        }
        /// <summary>
        /// Overrides the abstract method in BakeryItem to calculated the price 
        /// </summary>
        /// <returns>
        /// Returns the total price of the object
        /// </returns>
        public override double CalcTotal()
        {
            return mWeight * base.Price;
        }
        /// <summary>
        /// Overrides the normal ToString() method and calls the baseclass ToString()
        /// </summary>
        /// <returns>
        /// Returns the total string of the item (including values in the baseclass)
        /// </returns>
        public override string ToString()
        {
            return base.ToString() + "\nWeight: " + mWeight.ToString() + " kg(s)";
        }
        /// <summary>
        /// Property!
        /// </summary>
        public double Weight
        {
            get { return this.mWeight; }
            set
            {
                if (InputUtility.ValidateDouble(value))
                {
                    this.mWeight = value;
                }
            }
        }
    }
}
