﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// BakeryManager.cs
// Tim Fielding 11/08/2013

namespace Assignment_6
{
    /// <summary>
    /// Enum containing the different bakerytypes
    /// </summary>
    public enum BakeryTypes
    {
        Cake,
        Cookie
    };
}
