﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    class Car
    {
        private string mName, // The name of the car... Cars have names!
            mBrand; // The brandname of the car
        private double mGasAmount, // The amount of gas in the car
            mGasPerKM; // The amount of gas wasted by the car per kilometer
        private int mKMToGo; // The amount of kilometers you want to go

        public void Start() // Start-method, similar to the one in Part1
        {
            ReadInput();
            PrintResult();
        }

        private void ReadInput() // Same as above
        {
            ReadName();
            ReadBrand();
            ReadGasAmount();
            ReadGasPerKilometer();
            ReadKilometersToGo();
        }

        private void PrintResult() // This method prints the result of the drive
        {
            if (CalculateGas())
                Print("You made it with " + mGasAmount + " liter(s) left!"); // If you make it, it's awesome :D
            else
                Print("Sorry, you didn't make it, you needed " + (-mGasAmount) + " more liters of gas to make it."); // Inverts the negative amount of gas left to show how much more was needed
        }

        private void ReadName() // All the read-methods are pretty much the same as the ones in part1
        {
            Print("Name: ");
            mName = Convert.ToString(Read());
        }

        private void ReadBrand()
        {
            Print("Brand: ");
            mBrand = Convert.ToString(Read());
        }

        private void ReadGasAmount()
        {
            Print("Amount of gas (liters): ");
            mGasAmount = Convert.ToDouble(Read());
        }

        private void ReadGasPerKilometer()
        {
            Print("Gas per km (liters): ");
            mGasPerKM = Convert.ToDouble(Read());
        }

        private void ReadKilometersToGo()
        {
            Print("Kilometers to go: ");
            mKMToGo = Convert.ToInt16(Read());
        }

        private bool CalculateGas() // Calculates the amount of gas left after the drive and then returns true if the amount is above 0
        {
            mGasAmount -= mKMToGo * mGasPerKM;
            return mGasAmount > 0;
        }

        private void Print(string message) // I put the Console.Writeline method in here so I didn't have to write all that constantly
        {
            Console.WriteLine(message);
        }

        private string Read()
        {
            return Console.ReadLine();
        }
    }
}
