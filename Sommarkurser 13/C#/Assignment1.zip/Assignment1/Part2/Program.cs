﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "The gas game!";
            Console.WriteLine("The goal of this program is for you to input different car-related values, then\n" +
            "set a distance you want to go and see if you make it on the amount of gas you have!");

            Car car = new Car();

            car.Start();

            Console.WriteLine("Press any key to exit!");
            Console.Read();
        }
    }
}
