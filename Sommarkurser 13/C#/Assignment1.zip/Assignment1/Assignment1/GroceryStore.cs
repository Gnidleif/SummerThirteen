﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{
    class GroceryStore
    {
        static void Main(string[] args)
        {
            Console.Title = "GroceryStoreProgramOfAwesomeness";

            Product product = new Product();

            product.Start();

            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }
    }
}
