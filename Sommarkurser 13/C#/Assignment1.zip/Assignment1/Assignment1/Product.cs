﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{
    class Product
    {
        private string mName;
        private double mPrice;
        private int mQuantity;
        private bool mFoodItem;

        private double mTotalVAT;
        private double mTotalNetValue;

        private const double mFoodVATRate = 0.12, mOtherVATRate = 0.25;

        public void Start()
        {
            ReadInput();
            CalculateValues();
            PrintReceipt();
        }

        private void ReadInput()
        {
            ReadName();
            ReadNetUnitPrice();
            ReadIfFoodItem();
            ReadCount();
        }

        private void CalculateValues()
        {
            mTotalNetValue = mQuantity * mPrice;
            if (mFoodItem)
                mTotalVAT = mFoodVATRate * mTotalNetValue;
            else
                mTotalVAT = mOtherVATRate * mTotalNetValue;

            mTotalNetValue += mTotalVAT;
        }

        private void ReadName()
        {
            Console.Write("Name of product: ");
            mName = Convert.ToString(Console.ReadLine());
        }

        private void ReadNetUnitPrice()
        {
            Console.Write("Price: ");
            mPrice = Convert.ToDouble(Console.ReadLine());
        }

        private void ReadIfFoodItem()
        {
            Console.Write("Food item (Y/N): ");
            char response = char.Parse(Console.ReadLine());

            if ((response == 'y') || (response == 'Y'))
                mFoodItem = true;
            else
                mFoodItem = false;
        }

        private void ReadCount()
        {
            Console.Write("Amount: ");
            mQuantity = Convert.ToInt16(Console.ReadLine());
        }

        private void PrintReceipt()
        {
            Console.Write(
                "\nWELCOME TO ABUS AWESOME SUPERMEGADUPERTRUPERMARKET!" +
                "\nName of product: " + mName +
                "\nQuantity: " + mQuantity +
                "\nUnit price: " + mPrice +
                "\nFood item: " + mFoodItem +
                "\n\n" +
                "\nTotal price: " + mTotalNetValue +
                "\nTotal tax: " + mTotalVAT +
                "\n\n" +
                "\nThis program has been written by Tim Fielding.\n\n");
        }
    }
}
