﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class WasteSchedule
    { // Constants used for the different periods used in the calculations
        private const int mTotalPeriod = 52; // Total numbers of weeks
        private const int mBin1Period = 2; // The period of bin1
        private const int mBin2Period = 4; // The period of bin2

        public void Start()
        {
            int choice = -1;
            do // Used a do-while here, because of how this "menu"-thing is built, it needs to be run at least one time before exitting
            {
                ShowMenu();
                choice = int.Parse(Read());
                Write("");
                switch (choice)
                {
                    case 0: // Takes you back to the Menu-class Start method
                        Write("See you later!");
                        break;
                    case 1: // Shows the weeks that bin1 is taken care of
                        ShowBin1Weeks();
                        break;
                    case 2: // Shows the weeks that bin2 is taken care of
                        ShowBin2Weeks();
                        break;
                    default: // Default in case someone did something wrong
                        Write("Somewhere something went horribly wrong, try again!");
                        break;
                }
            } while (choice != 0); // Condition for my do-while
        }

        private void ShowMenu() // Menu description
        {
            Write("0 : Go back to main menu");
            Write("1 : Show weeks for Bin1(Household/Foodstuffs)");
            Write("2 : Show weeks for Bin2(Metal/Glass/Paper)");
            Console.Write("Choice: ");
        }
        // Used a for-loop in both of these were the i starts at the first period and jumps a period each iteration.
        // Ends while it's still less than the total amount of weeks in a year
        private void ShowBin1Weeks() 
        {
            for (int i = mBin1Period; i < mTotalPeriod; i += mBin1Period) // (start, end-condition, increment)
            {
                Write("Week: " + i); // I couldn't get the formatting to work correctly using the method described in the instructions, so I just went with this instead
            }
            Write("");
        }

        private void ShowBin2Weeks()
        {
            for (int i = mBin2Period; i < mTotalPeriod; i += mBin2Period)
            {
                Write("Week: " + i);
            }
            Write("");
        }

        private void Write(string str)
        {
            Console.WriteLine(str);
        }

        private string Read()
        {
            return Console.ReadLine();
        }
    }
}
