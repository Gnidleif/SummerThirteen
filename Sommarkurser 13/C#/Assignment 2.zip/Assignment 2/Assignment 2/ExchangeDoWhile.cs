﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class ExchangeDoWhile
    { // I wasn't quite sure what I was supposed to do in this part of the assignment, but I'm pretty sure I got the do-while loop down correctly
        private string mCurrencyName = "";
        private double mRate = 0.0;
        private double mSum = 0.0;

        public void Start()
        {
            WriteProgramInfo();
            ReadInputAndSumNumbers();
            ShowResults();
        }

        private void ReadInputAndSumNumbers() // Works the same as the floatingnumberswhile-method but with a do-while instead
        {
            double num = 0.0;
            bool done = false;

            do
            {
                Console.Write("Enter number: ");
                num = Double.Parse(Read());
                if (Math.Round(num, 5) == 0.0)
                    done = true;
                else
                    mSum += num;
            } while (!done);
        }

        private void WriteProgramInfo() // Meh
        {
            Write("Summation of foreign exchange, using do-while!");
            Write("Input 0 when you want to quit.");
            Write("");
        }

        private double ReadInput() // Same as in floatnumbers
        {
            return double.Parse(Read());
        }

        private void ShowResults() // Same
        {
            decimal converted = 0.0M; // Not sure if this is what I was supposed to do
            Write("Summation: " + mSum.ToString()); // But this is what I did :P
            Console.Write("Currency name: ");
            mCurrencyName = Read();
            Console.Write("Exchange rate: ");
            mRate = double.Parse(Read());
            converted = (decimal)(mSum * mRate);
            Write(mSum.ToString() + " converted to " + mCurrencyName + " = " + converted.ToString());
        }

        private void Write(string str)
        {
            Console.WriteLine(str);
        }

        private string Read()
        {
            return Console.ReadLine();
        }
    }
}
