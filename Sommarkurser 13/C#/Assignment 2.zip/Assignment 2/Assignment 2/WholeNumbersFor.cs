﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class WholeNumbersFor
    {
        private int // Member variables, initialized to 0
            mNumInput = 0, 
            mSum = 0;

        public void Start() // The usual Start-method
        {
            WriteProgramInfo();
            ReadInput();
            SumNumbers();
            ShowResults();
        }

        private void ReadInput() // Maybe this one shouldn't write AND read, but since it's only used for that in this class anyway, I made it like that
        {
            Console.Write("Number of values to sum? ");
            mNumInput = int.Parse(Read());
            Write("");
        }

        private void ShowResults() // Shows the total sum of all input
        {
            Write("Total sum: " + mSum);
            Write("");
        }

        private void SumNumbers() // Summarizes the numbers in a for-loop
        {
            for(int i = 0; i < mNumInput; i++)
            {
                Console.Write("Enter value no." + (i + 1) + ": ");
                int num = int.Parse(Read());
                mSum += num;
            }
            Write("");
        }

        private void WriteProgramInfo() // Method name says it all!
        {
            Write("Summation of whole numbers using a for-statement!");
        }

        private void Write(string str)
        {
            Console.WriteLine(str);
        }

        private string Read()
        {
            return Console.ReadLine();
        }
    }
}
