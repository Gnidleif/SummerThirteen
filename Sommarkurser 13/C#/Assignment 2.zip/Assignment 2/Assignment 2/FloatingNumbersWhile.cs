﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class FloatingNumbersWhile
    {
        private double mSum = 0.0; // Variable, initialized to 0.0

        public void Start() // Standard Start method
        {
            WriteProgramInfo();
            ReadInputAndSumNumbers();
            ShowResults();
        }

        private void ReadInputAndSumNumbers() // Reads input and sums it up with the member variable
        {
            double num = 0.0;
            bool done = false;
            while (!done)
            {
                Console.Write("Enter number: ");
                if ((Math.Round((num = ReadInput()), 5)) == 0.0) // Does it all in an if-statement!
                {
                    done = true; // If condition is met (input == 0), done is set to true
                }
                else
                    mSum += num; // Summarizing!
            }
            Write("");
        }

        private void WriteProgramInfo() // Methodname says it all
        {
            Write("Summation of floating numbers using while-loop!");
            Write("Input 0 when you want to quit.");
            Write("");
        }

        private double ReadInput() // Reads input, returns a parsed double
        {
            return double.Parse(Read());
        }

        private void ShowResults() // Prints the result to screen
        {
            Console.Write("Total sum of all numbers: " + mSum);
            Write("");
            Write("");
        }

        private void Write(string str)
        {
            Console.WriteLine(str);
        }

        private string Read()
        {
            return Console.ReadLine();
        }
    }
}
