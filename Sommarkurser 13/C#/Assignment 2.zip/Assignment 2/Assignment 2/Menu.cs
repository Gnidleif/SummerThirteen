﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class Menu
    {
        public void Start()
        {
            int choice = -1; // Went completely after the code-example in the instructions here
            while (choice != 0)
            {
                WriteMenuText();
                choice = int.Parse(Read());
                switch (choice)
                {
                    case 0: // Program exit
                        {
                            Write("Good bye!"); // 0 has it's own, polite case
                            break;
                        }
                    case 1: // Whole numbers using for
                        {
                            WholeNumbersFor localObject = new WholeNumbersFor();
                            localObject.Start();
                            break;
                        }
                    case 2: // Floating numbers while
                        {
                            FloatingNumbersWhile localObject = new FloatingNumbersWhile();
                            localObject.Start();
                            break;
                        }
                    case 3: // Exchange do while
                        {
                            ExchangeDoWhile localObject = new ExchangeDoWhile();
                            localObject.Start();
                            break;
                        }
                    case 4: // Waste schedule
                        {
                            WasteSchedule localObject = new WasteSchedule();
                            localObject.Start();
                            break;
                        }
                    default: // Default
                        {
                            Write("Incorrect choice, try again!"); // Just in case someone is silly and hits 5 or something
                            break;
                        }
                }
            }
        }

        private void WriteMenuText() // Straight forward menu
        {
            Console.Title = "Selection and iteration algorithms!";
            Write("Algorithms and iterations, pew pew!");
            Write("0 : Exit program");
            Write("1 : Whole Numbers with For");
            Write("2 : Floating Point Numbers with While");
            Write("3 : Currency Converter with Do While-Loop");
            Write("4 : WasteSchedule");
            Console.Write("Your choice: ");
        }

        private void WriteMessageCodeNotImplemented(int choice) // Obsolete method in the finished stage of the program, but it's still useful in case of expansions
        {
            string str = "Your choice is " + choice + " but the program is not yet complete!";
            str += Environment.NewLine + "Please come again!";
            Write(str);
        }

        private void Write(string str) // Write and Read are both implemented as my own methods in the classes below to avoid typing too much
        {
            Console.WriteLine(str);
        }

        private string Read()
        {
            return Console.ReadLine();
        }
    }
}