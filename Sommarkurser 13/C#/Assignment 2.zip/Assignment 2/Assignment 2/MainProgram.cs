﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class MainProgram
    {
        static void Main(string[] args) // Not a lot of commenting needed here, just initializing the menu
        {
            Menu menu = new Menu();
            menu.Start();
            Console.Read();
        }
    }
}
